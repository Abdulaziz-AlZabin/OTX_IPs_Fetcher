# otx-pulse-watcher

Polls AlienVault OTX's **global pulse activity feed** for new threat-intel
pulses, builds a plain-text wordlist of malicious IPs from them, and shows
it happening live in a local web dashboard. Runs as two containers.

## Containers

- **`watcher`** — runs `otx_watch.py --watch`, polling OTX every 5 minutes.
- **`dashboard`** — runs `webui.py`, serving the live view on
  `http://127.0.0.1:8787` (bound to localhost only, no auth).

Both share a bind-mounted `./data` directory:

- `data/pulses.jsonl` — one JSON record per new pulse (id, name, author,
  timestamps, tags, TLP, indicator count, and the IPs it contributed).
- `data/ip_log.jsonl` — chronological log of every new IP as it's extracted
  (ip, source pulse, timestamp) — what drives the dashboard's live feed.
- `data/malicious_ips.txt` — the wordlist: every IP seen, deduplicated and
  sorted, one per line. Feed straight into `ipset`, `fail2ban`, a firewall
  blocklist, or `grep -f`.
- `data/state.json` — bookkeeping (last poll cursor, recently-seen pulse
  IDs) so restarts don't reprocess old pulses. Don't edit by hand; delete it
  to force a full re-scan.

## Setup

```bash
printf 'OTX_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n' > .env
chmod 600 .env
```

Get a key from https://otx.alienvault.com/settings → *API Integration*.

## Run

```bash
docker compose up -d --build     # build + start both containers
docker compose logs -f watcher   # watch it poll
docker compose ps
```

Open **http://127.0.0.1:8787** for the dashboard.

```bash
docker compose down              # stop everything (data/ is untouched)
docker compose restart dashboard # after editing dashboard.html / webui.py
docker compose up -d --build     # after editing otx_watch.py / webui.py
```

### Rootless Podman note

This host runs Podman via the `docker` CLI shim. Rootless Podman remaps
container UIDs by default, so a container's UID 1000 is *not* the same as
your host UID 1000 — writes to a bind mount owned by your host user can get
a `Permission denied` the first time. If that happens:

```bash
chmod -R 777 data/
```

(Fine for a single-user local tool; not something to do on a shared host.)
`podman-restart.service` is enabled so containers with `restart: unless-stopped`
come back after a reboot — lingering is also enabled so that works even
without an active login session.

## Tuning

- Poll interval: edit `--interval` in `docker-compose.yml`'s `watcher`
  command (keep the `dashboard` command's `--poll-interval` matching it —
  it's only used to judge the watcher's health when `systemctl` isn't
  available, which is always true inside a container).
- First-run lookback window: add `--since-hours N` to the `watcher` command
  (only matters when `data/state.json` doesn't exist yet).
- Expose the dashboard beyond localhost: change the `ports` mapping in
  `docker-compose.yml` from `127.0.0.1:8787:8787` to `8787:8787` — there's
  no authentication, so only do this on a trusted network.

## Notes

- Uses the OTX *activity* feed (`/api/v1/pulses/activity`), which covers
  every public pulse on OTX as it's created/modified — not just pulses you
  personally subscribe to. It typically lags real-world events by a day or
  so; quiet stretches in the feed are normal, not a bug.
- `malicious_ips.txt` only ever grows — OTX doesn't signal "this indicator
  is no longer malicious," so treat it as a historical IOC list, not a live
  reputation feed. Prune it yourself if you need aging-out.
- The API key lives only in `.env` (`chmod 600`, git-ignored via
  `.dockerignore`) and is passed to the `watcher` container at runtime via
  `env_file` — it is never baked into the image.
