#!/usr/bin/env python3
"""
otx_watch.py — Poll AlienVault OTX for new pulses and build a malicious-IP wordlist.

For each run (or each tick, with --watch):
  1. Pulls every pulse from the OTX *global* activity feed modified since the
     last run (not just pulses you're subscribed to).
  2. Appends one JSON line per new pulse to pulses.jsonl  (the pulse record).
  3. Extracts every IPv4 / IPv6 indicator from those pulses into
     malicious_ips.txt — a flat, deduplicated, sorted wordlist (one IP per
     line, suitable for fail2ban, iptables/ipset, a firewall blocklist, grep, etc).

State (last timestamp seen + a rolling set of pulse IDs, to survive overlap
at the boundary) is kept in state.json next to the output files, so re-runs
are incremental.

Usage:
    export OTX_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    python3 otx_watch.py                      # one run
    python3 otx_watch.py --watch --interval 300   # poll every 5 min, forever
    python3 otx_watch.py --since-hours 72     # first run: look back 72h instead of 24h

Get an API key from: https://otx.alienvault.com/settings  (API Integration tab)
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime, timedelta, timezone

import requests

OTX_BASE = "https://otx.alienvault.com"
ACTIVITY_ENDPOINT = "/api/v1/pulses/activity"
IP_TYPES = {"IPv4", "IPv6"}

DEFAULT_OUT_DIR = os.path.dirname(os.path.abspath(__file__))
MAX_SEEN_IDS = 20000          # rolling window of pulse IDs kept for dedupe
REQUEST_PAGE_DELAY = 1.0      # seconds between paginated requests (be polite to the API)
RETRY_BACKOFF = [5, 15, 60]   # seconds, on transient HTTP errors / rate limiting


def log(msg: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[{ts}] {msg}", file=sys.stderr, flush=True)


def load_state(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        log(f"WARNING: could not parse state file {path}, starting fresh")
        return {}


def save_state(path: str, state: dict) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, path)


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]


def fetch_pulses_since(api_key: str, since_iso: str):
    """Yield pulse dicts from the OTX global activity feed, modified since `since_iso`."""
    headers = {"X-OTX-API-KEY": api_key}
    url = OTX_BASE + ACTIVITY_ENDPOINT
    params = {"modified_since": since_iso, "limit": 50}

    while url:
        attempt = 0
        while True:
            try:
                resp = requests.get(url, headers=headers, params=params, timeout=30)
            except requests.RequestException as e:
                attempt += 1
                if attempt > len(RETRY_BACKOFF):
                    raise
                wait = RETRY_BACKOFF[attempt - 1]
                log(f"network error ({e}), retrying in {wait}s")
                time.sleep(wait)
                continue

            if resp.status_code == 429:
                attempt += 1
                if attempt > len(RETRY_BACKOFF):
                    resp.raise_for_status()
                wait = RETRY_BACKOFF[attempt - 1]
                log(f"rate limited (429), retrying in {wait}s")
                time.sleep(wait)
                continue

            resp.raise_for_status()
            break

        data = resp.json()
        for pulse in data.get("results", []):
            yield pulse

        url = data.get("next")
        params = None  # `next` already carries the query string
        if url:
            time.sleep(REQUEST_PAGE_DELAY)


def extract_ips(pulse: dict):
    """Return the set of IPv4/IPv6 indicator strings in a pulse."""
    ips = set()
    for ind in pulse.get("indicators", []):
        if ind.get("type") in IP_TYPES:
            value = (ind.get("indicator") or "").strip()
            if value:
                ips.add(value)
    return ips


def pulse_summary(pulse: dict, fetched_ips: set) -> dict:
    return {
        "id": pulse.get("id"),
        "name": pulse.get("name"),
        "author": (pulse.get("author_name") or pulse.get("author", {}).get("username")),
        "created": pulse.get("created"),
        "modified": pulse.get("modified"),
        "tlp": pulse.get("TLP") or pulse.get("tlp"),
        "tags": pulse.get("tags", []),
        "indicator_count": len(pulse.get("indicators", [])),
        "ip_count": len(fetched_ips),
        "ips": sorted(fetched_ips, key=_ip_sort_key),
        "fetched_at": iso(datetime.now(timezone.utc)),
    }


def run_once(api_key: str, out_dir: str, state_path: str, since_hours: int) -> int:
    """Returns number of new pulses recorded."""
    state = load_state(state_path)
    seen_ids = set(state.get("seen_pulse_ids", []))

    if "last_modified_since" in state:
        since_iso = state["last_modified_since"]
    else:
        since_iso = iso(datetime.now(timezone.utc) - timedelta(hours=since_hours))
        log(f"no prior state, first run looking back {since_hours}h (since {since_iso})")

    run_started_at = iso(datetime.now(timezone.utc))

    pulses_path = os.path.join(out_dir, "pulses.jsonl")
    ips_path = os.path.join(out_dir, "malicious_ips.txt")
    ip_log_path = os.path.join(out_dir, "ip_log.jsonl")

    existing_ips = set()
    if os.path.exists(ips_path):
        with open(ips_path, "r") as f:
            existing_ips = {line.strip() for line in f if line.strip()}

    new_pulse_count = 0
    new_ip_count = 0
    all_ips = set(existing_ips)

    try:
        with open(pulses_path, "a") as pulses_f, open(ip_log_path, "a") as ip_log_f:
            for pulse in fetch_pulses_since(api_key, since_iso):
                pid = pulse.get("id")
                if pid in seen_ids:
                    continue  # already recorded in a prior overlapping run

                ips = extract_ips(pulse)
                summary = pulse_summary(pulse, ips)
                pulses_f.write(json.dumps(summary) + "\n")
                pulses_f.flush()

                seen_ids.add(pid)
                new_ips = ips - all_ips
                all_ips |= ips
                new_pulse_count += 1
                new_ip_count += len(new_ips)

                now_iso = iso(datetime.now(timezone.utc))
                for ip in sorted(new_ips, key=_ip_sort_key):
                    ip_log_f.write(json.dumps({
                        "ip": ip,
                        "pulse_id": pid,
                        "pulse_name": summary["name"],
                        "seen_at": now_iso,
                    }) + "\n")
                ip_log_f.flush()

                log(f"pulse '{summary['name']}' (id={pid}) -> "
                    f"{len(ips)} IP indicator(s), {len(new_ips)} new")
    finally:
        if len(all_ips) != len(existing_ips):
            tmp = ips_path + ".tmp"
            with open(tmp, "w") as f:
                f.write("\n".join(sorted(all_ips, key=_ip_sort_key)) + "\n")
            os.replace(tmp, ips_path)

        if len(seen_ids) > MAX_SEEN_IDS:
            seen_ids = set(list(seen_ids)[-MAX_SEEN_IDS:])

        state["last_modified_since"] = run_started_at
        state["seen_pulse_ids"] = list(seen_ids)
        save_state(state_path, state)

    log(f"run complete: {new_pulse_count} new pulse(s), {new_ip_count} new IP(s), "
        f"{len(all_ips)} total IP(s) in wordlist")
    return new_pulse_count


def _ip_sort_key(ip: str):
    # Sort IPv4 numerically, IPv6 (and anything odd) lexically after it.
    parts = ip.split(".")
    if len(parts) == 4 and all(p.isdigit() for p in parts):
        return (0, tuple(int(p) for p in parts))
    return (1, ip)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--api-key", default=os.environ.get("OTX_API_KEY"),
                     help="OTX API key (default: $OTX_API_KEY)")
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR,
                     help="directory for pulses.jsonl / malicious_ips.txt (default: script dir)")
    ap.add_argument("--state-file", default=None,
                     help="path to state.json (default: <out-dir>/state.json)")
    ap.add_argument("--since-hours", type=int, default=24,
                     help="on first run (no state file), how far back to look (default: 24)")
    ap.add_argument("--watch", action="store_true",
                     help="run forever, polling every --interval seconds")
    ap.add_argument("--interval", type=int, default=300,
                     help="seconds between polls in --watch mode (default: 300)")
    args = ap.parse_args()

    if not args.api_key:
        ap.error("no API key: pass --api-key or set OTX_API_KEY "
                  "(get one at https://otx.alienvault.com/settings)")

    os.makedirs(args.out_dir, exist_ok=True)
    state_path = args.state_file or os.path.join(args.out_dir, "state.json")

    if args.watch:
        log(f"watching OTX activity feed every {args.interval}s "
            f"(Ctrl+C to stop) -> {args.out_dir}")
        while True:
            try:
                run_once(args.api_key, args.out_dir, state_path, args.since_hours)
            except requests.HTTPError as e:
                log(f"ERROR: HTTP {e.response.status_code if e.response else '?'}: {e}")
            except Exception as e:
                log(f"ERROR: {e}")
            try:
                time.sleep(args.interval)
            except KeyboardInterrupt:
                log("stopped")
                return 0
    else:
        try:
            run_once(args.api_key, args.out_dir, state_path, args.since_hours)
        except requests.HTTPError as e:
            log(f"ERROR: HTTP {e.response.status_code if e.response else '?'}: {e}")
            return 1
        return 0


if __name__ == "__main__":
    sys.exit(main())
