#!/usr/bin/env python3
"""
webui.py — local dashboard for otx_watch.py.

Serves a single dashboard page (dashboard.html) plus a small JSON API that
reads pulses.jsonl, ip_log.jsonl, malicious_ips.txt and state.json straight
off disk — it never talks to OTX itself, it just watches what otx_watch.py
has already written. The dashboard polls the API every few seconds so you
can watch pulses arrive and IPs land in the wordlist in near-real-time.

Usage:
    ./webui.py                       # serve on 127.0.0.1:8787, data files next to this script
    ./webui.py --port 9000
    ./webui.py --host 0.0.0.0        # expose beyond localhost (no auth — be careful)
    ./webui.py --data-dir /data      # read otx_watch.py's output from elsewhere (e.g. in a container)
"""

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DASHBOARD_PATH = os.path.join(BASE_DIR, "dashboard.html")  # ships with the code, not the data
SERVICE_NAME = "otx-watch.service"

# Data file locations — set from --data-dir in main(); default matches the
# pre-container layout where everything lived next to the scripts.
PULSES_PATH = os.path.join(BASE_DIR, "pulses.jsonl")
IP_LOG_PATH = os.path.join(BASE_DIR, "ip_log.jsonl")
WORDLIST_PATH = os.path.join(BASE_DIR, "malicious_ips.txt")
STATE_PATH = os.path.join(BASE_DIR, "state.json")

# How often otx_watch.py polls — only used as a staleness threshold when
# systemctl isn't available (e.g. running in a container) to guess whether
# the watcher process is still alive. Set from --poll-interval in main().
POLL_INTERVAL = 300


def read_jsonl_tail(path, limit):
    """Return up to `limit` most recent records from a JSONL file, newest first."""
    if not os.path.exists(path):
        return []
    with open(path, "r") as f:
        lines = f.readlines()
    out = []
    for line in lines[-limit:]:
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    out.reverse()
    return out


def count_jsonl(path):
    if not os.path.exists(path):
        return 0
    with open(path, "r") as f:
        return sum(1 for line in f if line.strip())


def count_lines(path):
    if not os.path.exists(path):
        return 0
    with open(path, "r") as f:
        return sum(1 for line in f if line.strip())


def service_status(name):
    """Best-effort watcher health: systemctl on the host, or a freshness
    heuristic (state.json updated recently enough) when systemctl isn't
    available at all — e.g. inside a container, where the watcher is a
    separate process/container we have no direct handle on."""
    try:
        res = subprocess.run(
            ["systemctl", "--user", "is-active", name],
            capture_output=True, text=True, timeout=2,
        )
        return res.stdout.strip() or "unknown"
    except FileNotFoundError:
        pass  # no systemctl in this environment — fall through to heuristic
    except Exception:
        return "unknown"

    if not os.path.exists(STATE_PATH):
        return "unknown"
    age = datetime.now(timezone.utc).timestamp() - os.path.getmtime(STATE_PATH)
    return "active" if age < max(POLL_INTERVAL * 2.5, 60) else "stale"


def build_summary():
    state = {}
    if os.path.exists(STATE_PATH):
        try:
            with open(STATE_PATH) as f:
                state = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    latest_pulses = read_jsonl_tail(PULSES_PATH, 1)
    latest_pulse = latest_pulses[0] if latest_pulses else None

    return {
        "total_pulses": count_jsonl(PULSES_PATH),
        "total_ips": count_lines(WORDLIST_PATH),
        "last_cursor": state.get("last_modified_since"),
        "latest_pulse_name": latest_pulse["name"] if latest_pulse else None,
        "latest_pulse_fetched_at": latest_pulse["fetched_at"] if latest_pulse else None,
        "service_status": service_status(SERVICE_NAME),
        "server_time": datetime.now(timezone.utc).isoformat(timespec="seconds") + "Z",
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "OTXDashboard/1.0"

    def log_message(self, fmt, *args):
        pass  # keep stdout/journal quiet for routine polling

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path, content_type):
        if not os.path.exists(path):
            self.send_error(404, "not found")
            return
        with open(path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)

        if parsed.path in ("/", "/index.html"):
            self._file(DASHBOARD_PATH, "text/html; charset=utf-8")
        elif parsed.path == "/api/summary":
            self._json(build_summary())
        elif parsed.path == "/api/pulses":
            limit = int(qs.get("limit", ["30"])[0])
            self._json(read_jsonl_tail(PULSES_PATH, limit))
        elif parsed.path == "/api/ip_log":
            limit = int(qs.get("limit", ["60"])[0])
            self._json(read_jsonl_tail(IP_LOG_PATH, limit))
        else:
            self.send_error(404, "not found")


def main():
    global PULSES_PATH, IP_LOG_PATH, WORDLIST_PATH, STATE_PATH, POLL_INTERVAL

    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", default="127.0.0.1",
                     help="bind address (default: 127.0.0.1, localhost only)")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--data-dir", default=BASE_DIR,
                     help="directory holding pulses.jsonl / ip_log.jsonl / "
                          "malicious_ips.txt / state.json (default: next to this script)")
    ap.add_argument("--poll-interval", type=int, default=300,
                     help="otx_watch.py's --interval, used only to judge staleness "
                          "when systemctl isn't available (default: 300)")
    args = ap.parse_args()

    PULSES_PATH = os.path.join(args.data_dir, "pulses.jsonl")
    IP_LOG_PATH = os.path.join(args.data_dir, "ip_log.jsonl")
    WORDLIST_PATH = os.path.join(args.data_dir, "malicious_ips.txt")
    STATE_PATH = os.path.join(args.data_dir, "state.json")
    POLL_INTERVAL = args.poll_interval

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"OTX dashboard serving on http://{args.host}:{args.port}  (Ctrl+C to stop)",
          file=sys.stderr)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
